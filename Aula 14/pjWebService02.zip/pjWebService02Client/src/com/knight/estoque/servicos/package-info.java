@javax.xml.bind.annotation.XmlSchema(namespace = "http://servicos.estoque.knight.com/")
package com.knight.estoque.servicos;
