package com.knight.estoque.daos;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.knight.estoque.modelos.Livro;

public class LivroDAO {

	public List<Livro> listarLivros() {
		List<Livro> livros = new ArrayList<>();
		livros.add(new Livro(2012, new ArrayList<>(Arrays.asList("Deitel", "Deitel")), "Pearson", "Java Como Programar", "Do b�sico ao intermedi�rio"));
		livros.add(new Livro(2012, new ArrayList<>(Arrays.asList("Vin�cius Baggio Fuentes")), "Casa do C�digo", "Ruby on Rails", "Crie rapidamente aplica��es web"));
		return livros;
	}
	
	
	public List<Livro> listarLivros(Integer numeroDaPagina, Integer tamanhoDaPagina) {
		List<Livro> livros = listarLivros();
		
		int indiceInicial = numeroDaPagina * tamanhoDaPagina;
		int indiceFinal = indiceInicial + tamanhoDaPagina;
		
		indiceFinal = indiceFinal > livros.size() ? livros.size() : indiceFinal; 
		indiceInicial = indiceInicial > indiceFinal ? indiceFinal : indiceInicial;
		
		return livros.subList(indiceInicial, indiceFinal);		
	}
}